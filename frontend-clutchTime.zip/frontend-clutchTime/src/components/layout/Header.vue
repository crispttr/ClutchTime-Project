<template>
  <header class="header">
    <span>Hello, {{ authStore.userName }}</span>
    <button @click="handleLogout">🔒 Déconnexion</button>
  </header>
</template>

<script setup>
import { useAuthStore } from '@/store/auth'
const authStore = useAuthStore()

// ✅ Correction : Bien appeler la fonction de déconnexion
const handleLogout = async () => {
  await authStore.logout()
}
</script>

<style scoped>
.header {
  background-color: #62a8e5;
  color: white;
  padding: 1rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header button {
  background-color: #ff8c42;
  color: white;
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.header button:hover {
  opacity: 0.9;
}
</style>
