import axios from 'axios'

const api = axios.create({
  baseURL: 'http://localhost:8000', // Mettre l'URL de ton backend Laravel
  withCredentials: true, // ✅ Gérer les cookies d'authentification
})

export default api
