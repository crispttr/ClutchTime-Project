<template>
  <div class="story-wrapper">
    <div class="top-bar">
      <div class="top-right">
        <!-- ✅ Bouton Accueil pour revenir -->
        <button class="home" @click="goHome">🏠 Accueil</button>
      </div>
    </div>

    <div class="story-content">
      <h2>{{ chapter.title }}</h2>
      <p>{{ chapter.content }}</p>

      <div class="choices">
        <button
          v-for="choice in chapter.choices"
          :key="choice.id"
          @click="selectChoice(choice.next_chapter_id)"
        >
          {{ choice.text }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/store/auth'
import api from '@/axios'

const authStore = useAuthStore()
const router = useRouter()
const route = useRoute()

const chapter = ref({ title: '', content: '', choices: [] })

// ✅ Fonction pour retourner à l'accueil
const goHome = () => {
  router.push('/accueil')
}

const fetchChapter = async (id, storyId) => {
  try {
    const res = await api.get(`/api/v1/chapters/${id}`, { withCredentials: true })
    chapter.value = res.data
    await authStore.saveProgression(storyId, id) // ✅ Sauvegarder la progression
  } catch (err) {
    console.error('Erreur lors du chargement du chapitre:', err)
  }
}

const selectChoice = async (nextId) => {
  try {
    const storyId = route.query.story
    await fetchChapter(nextId, storyId)
  } catch (err) {
    console.error('Erreur lors du choix:', err)
  }
}

onMounted(() => {
  const storyId = route.query.story
  const chapterId = route.query.chapter || 1
  fetchChapter(chapterId, storyId)
})
</script>

<style scoped>
.story-wrapper {
  padding: 2rem;
}

.top-bar {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  margin-bottom: 1rem;
}

.home {
  padding: 0.5rem 1rem;
  background: #1976d2;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.home:hover {
  background: #125ca1;
}

.story-content {
  margin: auto;
  text-align: center;
  max-width: 600px;
  padding: 2rem;
  background: #fff;
  border-radius: 10px;
  box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
}

.choices button {
  margin: 1rem 0;
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  background: #ffb310;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}

.choices button:hover {
  background: #e58f00;
}
</style>
