<template>
  <div class="page-container">
    <h2>📚 Histoires disponibles</h2>
    <div v-if="stories.length" class="story-list">
      <div v-for="story in stories" :key="story.id" class="story-card">
        <h3>{{ story.title }}</h3>
        <p>{{ story.description }}</p>

        <div v-if="authStore.progressions[story.id]" class="button-group">
          <button @click="goToStory(story.id, authStore.progressions[story.id])">
            ▶️ Reprendre
          </button>
          <button @click="resetProgression(story.id)">🔁 Recommencer</button>
        </div>

        <!-- ✅ Correction : Vérifier l'appel de startStory -->
        <button @click="startStory(story.id)">Commencer</button>
      </div>
    </div>
    <p v-else>Chargement des histoires...</p>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/store/auth'
import api from '@/axios'

const authStore = useAuthStore()
const router = useRouter()
const stories = ref([])

// ✅ Correction : Vérifier la fonction startStory
const startStory = (storyId) => {
  try {
    router.push({ path: '/story', query: { story: storyId } })
  } catch (err) {
    console.error("Erreur lors du démarrage de l'histoire:", err)
  }
}

const goToStory = (storyId, chapterId) => {
  router.push({ path: '/story', query: { story: storyId, chapter: chapterId } })
}

const resetProgression = async (storyId) => {
  await authStore.resetProgression(storyId)
}

const fetchStories = async () => {
  try {
    const res = await api.get('/api/v1/stories', { withCredentials: true })
    stories.value = res.data

    for (const story of stories.value) {
      await authStore.fetchProgression(story.id)
    }
  } catch (err) {
    console.error('Erreur lors du chargement des histoires:', err)
  }
}

onMounted(fetchStories)
</script>

<style scoped>
.page-container {
  padding: 1rem;
}

.story-list {
  display: grid;
  gap: 1.5rem;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
}

.story-card {
  background-color: white;
  padding: 1.5rem;
  border-radius: 8px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}
</style>
